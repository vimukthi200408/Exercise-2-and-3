﻿namespace ex1q8
{
    class Program
    {
        static void Main(string[] args)
        {
            string stName, stNum, grade;
            int mark1, mark2, mark3, total, avg;


            Console.Write("Enter the student number : ");
            stNum = Console.ReadLine();

            Console.Write("Enter the student name : ");
            stName = Console.ReadLine();

            Console.Write("Enter the mark 1 : ");
            mark1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the mark 2 : ");
            mark2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the mark 3 : ");
            mark3 = Convert.ToInt32(Console.ReadLine());

            total = mark1 + mark2 + mark3;
            avg = total / 3;

            if (avg > 50)
            {
                grade = "Pass";
            }
            else
            {
                grade = "Fail";
            }


            Console.WriteLine(" ");
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Student Number : " + stNum);
            Console.WriteLine("Studnet Name : " + stName);
            Console.WriteLine("Total Mark : " + total);
            Console.WriteLine("Average Mark : " + avg);
            Console.WriteLine("Grade : " + grade);



        }
    }
}