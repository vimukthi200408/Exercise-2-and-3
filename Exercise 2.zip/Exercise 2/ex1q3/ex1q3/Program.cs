﻿namespace ex1q3
{
    class Program
    {
        static void Main(string[] args)
        {
            string name;

            //this is getting the input from the user and storing it
            Console.Write("Enter your name : ");
            name = Console.ReadLine();

            // outputing the message with the stored value
            Console.WriteLine("Hello " + name);
        }
    }
}