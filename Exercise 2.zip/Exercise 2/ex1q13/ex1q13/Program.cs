﻿namespace ex1q13
{
    class Program
    {
        static void Main(string[] args)
        {
            
                double r, h, sa = 0, v = 0, PI = 2.14;

                Console.Write("Enter the radius of the base : ");
                r = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter the height : ");
                h = r = Convert.ToDouble(Console.ReadLine());

            sa = 2 * PI * r * h;
                v = PI * r * r * h;

            Console.WriteLine("The surface area is : " + sa);
            Console.WriteLine("The volume is : " + v);
            
        }

    
    }
}