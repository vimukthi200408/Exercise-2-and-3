﻿namespace ex1q4
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, tot;

            //getting the number 1 and number 2 from the user and storing them
            Console.Write("Enter the first number : ");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the second number : ");
            num2 = Convert.ToInt32(Console.ReadLine());

            //calculating the additon 
            tot = num1 + num2;


            Console.Write("The addition is : "+ tot);

        }
    }
}