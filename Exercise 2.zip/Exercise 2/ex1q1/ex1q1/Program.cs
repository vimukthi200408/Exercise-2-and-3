﻿namespace ex1q1
{
    class Hello
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello Programming");
        }
    }
}