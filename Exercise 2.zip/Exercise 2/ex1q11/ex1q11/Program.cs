﻿namespace ex1q11
{
    class Program
    {
        static void Main(string[] args)
        {
            double PI = 3.14, radius, area, circumference;

            Console.Write("Enter the radius of the circle : ");
            radius = Convert.ToDouble(Console.ReadLine());

            circumference = 2 * PI * radius;
            area = PI * (radius * radius);

            Console.WriteLine(" ");
            Console.WriteLine("The area of the circle is : "+ area);
            Console.WriteLine("The circumference of the circle is : " + circumference);

        }
    }
}