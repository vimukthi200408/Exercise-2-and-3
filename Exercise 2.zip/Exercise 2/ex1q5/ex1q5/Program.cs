namespace ex1q5
{
    class Program
    {
        static void Main(string[] args)
        {
            string salesmanName, salesmanNum;
            int unitsSold;
            double unitPrice, salesValue;


            Console.Write("Enter the salesman number : ");
            salesmanNum = Console.ReadLine();

            Console.Write("Enter the salesman name : ");
            salesmanName = Console.ReadLine();

            Console.Write("Enter the number of units sold : ");
            unitsSold = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the unit price : ");
            unitPrice = Convert.ToDouble(Console.ReadLine());

            salesValue = unitPrice * unitsSold;

            Console.WriteLine(" ");
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Salesman number : " + salesmanNum);
            Console.WriteLine("Salesman name : "+ salesmanName);
            Console.WriteLine("Sales values : "+salesValue);
           


        }
    }
}