﻿namespace ex1q14
{
    class Program
    {
         

            static void Main(string[] args)
            {
                
                int option;


                bool e = false;

                do
                {

                    Console.WriteLine("1. Circle");
                    Console.WriteLine("2. Rectangle");
                    Console.WriteLine("3. Cylinder");
                    option = Convert.ToInt32(Console.ReadLine());
                    switch (option)
                    {
                        case 1:
                        Console.WriteLine("The area and the circumference of the circle");
                            circle();
                            e = true;
                            break;
                        case 2:
                        Console.WriteLine("The perimeter and the area of the rectangle");
                            rectangle();
                            e = true;
                            break;
                        case 3:
                        Console.WriteLine("The surface area and the volume of the cylinder");
                            cylinder();
                            e = true;
                            break;
                        default:

                            e = false;
                        Console.WriteLine("Error");
                        break;
                    }
                } while (e == false);
            Console.ReadKey();

            }

        static void circle()
        {
            double r = 0, c = 0, a = 0, PI = 2.14;

            Console.Write("Enter the radius : ");
            r = Convert.ToDouble(Console.ReadLine());

            c = 2 * PI * r;
            a = PI * r * r;

            Console.WriteLine("The Circumference = " + c);
            Console.WriteLine("The Area is = " + a);
        }

        static void rectangle()
        {
            int h, w, a = 0, p = 0;

            Console.Write("Enter the Height of the rectangle : ");
            h = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the width : ");
            w = Convert.ToInt32(Console.ReadLine());

            p = 2 * (h + w);
            a = h * w;

            Console.WriteLine("The perimeter is : " + p);
            Console.WriteLine("The Area is : " + a);
        }

        static void cylinder()
        {

            double r, h, sa = 0, v = 0, PI = 2.14;
            Console.Write("Enter the radius of the base : ");
            r = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the height : ");
            h = Convert.ToDouble(Console.ReadLine());

            sa = 2 * PI * r * h;
            v = PI * r * r * h;

            Console.WriteLine("The surface area is : " + sa);
            Console.WriteLine("The volume is : " + v);
        }


    }

}