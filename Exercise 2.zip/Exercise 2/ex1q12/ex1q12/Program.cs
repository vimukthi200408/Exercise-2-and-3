﻿namespace ex1q12
{
    class Program
    {
        static void Main(string[] args)
        {
           
                int h, w, a = 0, p = 0;


                Console.Write("Enter the Height of the rectangle : ");
                h = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the width : ");
                w = Convert.ToInt32(Console.ReadLine());

            p = 2 * (h + w);
                a = h * w;

            Console.WriteLine("The perimeter is : " + p);
            Console.WriteLine("The Area is : " + a);
        }
        
    }
}