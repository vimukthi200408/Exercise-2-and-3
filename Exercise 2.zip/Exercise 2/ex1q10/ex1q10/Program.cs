﻿namespace ex1q10
{
    class Program
    {
        static void Main(string[] args)
        {
            string salesmanName, salesmanNum;
            int unitsSold;
            double unitPrice, salesValue, commisson = 0, finalSal, basicSal = 25000;


            Console.Write("Enter the salesman number : ");
            salesmanNum = Console.ReadLine();

            Console.Write("Enter the salesman name : ");
            salesmanName = Console.ReadLine();

            Console.Write("Enter the number of units sold : ");
            unitsSold = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the unit price : ");
            unitPrice = Convert.ToDouble(Console.ReadLine());

            salesValue = unitPrice * unitsSold;

            if (salesValue >= 50000)
            {
                commisson = salesValue * 0.1;
            }

            finalSal = basicSal + commisson;



            Console.WriteLine(" ");
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Salesman number : " + salesmanNum);
            Console.WriteLine("Salesman name : " + salesmanName);
            Console.WriteLine("Sales values : " + salesValue);
            Console.WriteLine("Commission : " + commisson);
            Console.WriteLine("Final Salary : " + finalSal);



        }
    }
}