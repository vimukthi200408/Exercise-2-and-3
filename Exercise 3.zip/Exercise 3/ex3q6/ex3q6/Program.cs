﻿namespace ex3q6
{
    class Program

    {
        static void Main(string[] args)
        {
            int num1;
            int total = 0;
            int avg;
            int count = 0;

            Console.WriteLine("Enter positive numbers : ");
            do
            {
                num1 = Convert.ToInt32(Console.ReadLine());
                if (num1 > 0)
                {
                    total = total + num1;
                    count++;
                }
            }
            while (num1 > 0);

            Console.WriteLine("Count : " + count);
            Console.WriteLine("total : " + total);
            avg = total / count;
            Console.WriteLine("Average : " + avg);

        }
    }
}