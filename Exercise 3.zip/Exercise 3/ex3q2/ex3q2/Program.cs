﻿namespace ex3q2
{
    class Program
    {
        static void Main(string[] args)
        {
            int total = 0;

            for (int i = 1; i < 11; i++)
            {
                total = total + i;
            }
            Console.WriteLine("The sum of the first 10 natural number is : "+total);

        }
    }
}