﻿namespace exq5
{
    class Program
    {
        static void Main(string[] args)
        {
           
                
                int num1;

                Console.WriteLine("Enter a positive integer : ");
                num1 = Convert.ToInt16(Console.ReadLine());

                for (int i = 0; i <= 10; i++)
                {

                    Console.WriteLine(num1 + "x" + i + "=" + num1 * i);

                }







        }
      
    
    }
}