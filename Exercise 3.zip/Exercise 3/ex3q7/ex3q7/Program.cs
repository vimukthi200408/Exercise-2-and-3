﻿namespace ex3q7
{
    class Program

    {
        static void Main(string[] args)
        {

          

            int num1;
            int pos = 0;
            int neg = 0;
            

            Console.WriteLine("Enter 10 integers : ");

            for (int i = 0; i < 10; i++)
            {
                num1 = Convert.ToInt32(Console.ReadLine());

                if (num1 > 0)
                {
                    pos = pos + num1;
                }
                else
                {
                    neg = neg + num1;
                }

            }
            
            Console.WriteLine("The sum of positive numbers are : " + pos);
            Console.WriteLine("The sum of negative numbers are : " + neg);



        }
    }
}