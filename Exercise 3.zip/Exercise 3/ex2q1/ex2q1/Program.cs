﻿namespace ex2q1
{
    class Program
    {
        static void Main(string[] args)
        {
            double num1, num2, ans = 0;
            int option;

            Console.Write("Enter the first number : ");
            num1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter the second number : ");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine(" ");
            Console.WriteLine("Press 1 to Add");
            Console.WriteLine("Press 2 to Subtract");
            Console.WriteLine("Press 3 to Multiply");
            Console.WriteLine("Press 4 to Divide");
            Console.WriteLine("Press 5 to Remainder");
            Console.WriteLine(" ");
            Console.Write("Enter your option : ");
            option = Convert.ToInt32(Console.ReadLine());

            switch (option) {
                case 1:
                    Add(num1, num2);
                    break;
                case 2:
                    Sub(num1, num2);
                    break;
                case 3:
                    Mul(num1, num2);
                    break;
                case 4:
                    Divide(num1, num2);
                    break;
                case 5:
            
                 
                    Per(num1, num2);
                    break;


            }

           
            void Add(double num1, double num2)
            {
                ans = num1 + num2;
                Console.WriteLine("The answer is : " + ans);
            }

            void Sub(double num1, double num2)
            {
                ans = num1 - num2;
                Console.WriteLine("The answer is : " + ans);
            }

            void Mul(double num1, double num2)
            {
                ans = num1 * num2;
                Console.WriteLine("The answer is : " + ans);
            }

            void Divide(double num1, double num2)
            {
                ans = num1 / num2;
                Console.WriteLine("The answer is : " + ans);
            }

            void Per(double num1, double num2)
            {
                ans = num1 % num2;
                Console.WriteLine("The answer is : " + ans);
            }







        }
    }
}