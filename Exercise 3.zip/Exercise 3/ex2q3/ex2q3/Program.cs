﻿namespace ex3q3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;

            for (int i = 0; i < 100; i++)
            {
          
                if (i%2 != 0)
                {
                    Console.Write(" ");
                    Console.Write(i+" , ");
                }
            }
            

        }
    }
}