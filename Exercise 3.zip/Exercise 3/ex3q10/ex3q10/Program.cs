﻿namespace ex3q10
{
	class Program

	{
		static void Main(string[] args)
		{

		

				for (int j = 0; j < 5; j++)
				{
					for (int i = 0; i < 10; i++)
					{
						Console.Write("*");
					}
				Console.WriteLine("");
				}


			

		}






	}
}