﻿namespace ex3q4
{
    class Program
    {
        static void Main(string[] args)
        {
            int start, end, total = 0 ;

            Console.WriteLine("To find even numbers in a range");
            Console.Write("Enter the starting value : ");
            start = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the ending value : ");
            end = Convert.ToInt32(Console.ReadLine());

            for (int i = start; i <= end; i++)
            {

                if (i % 2 == 0)
                {
                    total = total + i;
                }
            }

            Console.WriteLine("The total of even number in that given range is "+total);


        }
    }
}