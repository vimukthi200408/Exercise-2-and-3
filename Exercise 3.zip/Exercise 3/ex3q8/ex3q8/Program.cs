﻿namespace ex3q7
{
    class Program

    {
        static void Main(string[] args)
        {



                int num1;
                int sum = 0;
                int avg = 0;
                int[] array = new int [10];
          
       
                for (int i = 0; i < 10; i++)
                {
                    Console.Write("Enter value " + i + " : ");
                    num1 = Convert.ToInt32(Console.ReadLine());

                    sum = sum + num1;
                    array[i] = num1;
                   
                }
            avg = sum / 10;

            Console.WriteLine("The total of the array is : " + sum);
                
                Console.WriteLine("The average of the array is : " + avg);
            

        }


    
      

    
    }
}