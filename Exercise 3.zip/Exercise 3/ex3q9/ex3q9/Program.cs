﻿namespace ex3q9
{
    class Program

    {
        static void Main(string[] args)
        {

				int[] array = new int [10];
				int num1;

				Console.WriteLine("Enter 10 numbers : ");

				for (int i = 0; i < 10; i++)
				{
					num1 = Convert.ToInt32(Console.ReadLine());
					array[i] = num1;
					
				}

				Console.WriteLine("_______________________________");

				//array.sort
				Array.Sort(array);
				foreach (int i in array)
				{
					Console.Write(i + " ");
				}




		}






    }
}